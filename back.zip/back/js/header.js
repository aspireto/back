$(function() {

    $(".contact .goTop").click(function(event) {
        $('html,body').animate({ scrollTop: 0 })
    });
    $(".close_contact").click(function() { //关闭首页侧边栏
        $(".contact").hide(300);
        $("span.tel").fadeIn(300);
    })

    $("span.tel").click(function() {
        $(".contact").show(300);
        $("span.tel").hide(300);
        return false;
    });
    $(window).scroll(function(event) {
        var sTop = $(window).scrollTop();
        var sTop = parseInt(sTop);
        if (sTop > 140) {
            $(".headerMenu").addClass("fixed_header");
            $(".fixed_header").slideDown();
        } else {
            $(".headerMenu").removeClass("fixed_header");
            $(".headerMenu").removeAttr("style");
        }
        if (sTop > $(window).height() / 2) {
            $(".contact .goTop").fadeIn('300');
        } else {
            $(".contact .goTop").fadeOut('300');
        }
    });
    $(".dropDownList ul li:first-child dl").css({ "padding-left": "0" });
    $(".dropDownList ul li:last-child dl").css({ "padding-right": "0", "border-right": "0" });
    $(".menuList ul li.indexActive ol li:last-child").css({ "border-bottom": "0", 'padding': '16px 15px' });
    $(".dropDownList ul.programmeList li:last-child").css({ "border-right": "0" });
    $(".menuList ul li.indexActive").hover(function() {
        $(this).find('ol').stop().slideDown('400');
        // $(this).find('ol').css('overflow','visible');
    }, function() {
        $(this).find('ol').stop().slideUp('1');
        //$(this).find('ol').stop().hide();
    });
    $(".menuList ul li.indexActive ol li").hover(function() {
        $(".menuList ul li.indexActive ol").css('overflow', 'visible');
        $(this).find('dl').show();
        $(this).siblings('').removeClass('active')
        $(this).siblings('').find('dl').hide();
        $(this).find('dl').animate({
            'width': '427px'
        }, 300);
    }, function() {
        $(this).find('dl').hide();
        $(this).find('dl').animate({
            'width': '300px'
        }, 1);
    });
    var windowWidth = document.body.scrollWidth;
    //var windowWidth=$(window).width();
    //alert(windowWidth);
    $(".dropDownList").css({ "width": windowWidth, "left": '-' + (windowWidth - 1200) / 2 + 'px' })
    $(".menuList ul li").hover(function() { //收银页面子菜单效果
        if ($(this).find('div').hasClass('dropDownList')) {
            $('.indexActive').find('ol').stop().slideUp('1');
        }
        $(this).find('.dropDownList').stop().slideDown('300');
    }, function() {
        $(this).find('.dropDownList').stop().hide();
    });
})
