/*****wangmu 11-30******/
$(function() {
    //四周年banner
    if(JudgeTime()){
		var actWindowStrVar = "";
			actWindowStrVar += "<section class=\"actWindow\" style=\"background-color:#000;left:0;right:0;bottom:0;opacity:.8;position:fixed;top:0;z-index:1000;filter:alpha(opacity=80);-moz-opacity:.8;-khtml-opacity:.8;display:block;z-index:1000;width:100%\"><div class=\"thisActMod\" style=\"position:fixed;width:629px;height:390px;top:50%;left:50%;margin-left:-315px;margin-top:-195px\"><em class=\"pa\" onclick=\"$(&quot;.actWindow&quot;).hide()\" style=\"right:0;top:0;width:37px;height:37px;cursor:pointer;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAlCAMAAADyQNAxAAAAw1BMVEUcHBwAAAD///8nJyf///8eHh45OTlRUVFdXV2SkpK0tLSwsLDb29vZ2dn+/v7///////////////////////////////////9KSkr7+/v19fWDg4M0NDQoKChJSUn////////y8vKhoaH////4+Pjq6urW1tbBwcG+vr6jo6OSkpJ6enpiYmJSUlJCQkIlJSVMTEz////////9/f3m5ubi4uLd3d3a2tpra2tmZmZYWFg4ODjt7e3Kysqenp6YmJj///+o9GcmAAAAQHRSTlPUAMXTttXS0dDMysrIyMW6qpeJZFssIxrc/v3m2NbRbT/8y3D9+vby8ezp5ODd2tbRa0D++fn49+Hg3tn79OvpiJfuYQAAAadJREFUOMuVlNdyg0AMRWXh3rsxDrZxiXtN4hKn6P+/KloWIiCZwT4vDOKOdCW0C4kgrWa9WsFKtd5sheIBVWeQRCE56PyjatcwSq0dVQ3dPKVcNm2Akc7mSm6+Y1jV4Fg53wehny9zrBFUjTlQzECYTJGjY1GpTAUDohgFPxsoT/wySsFfUiP+MtSqdpIziSgk42zJtquqsScpFynK3mpK1eHuxHiUDHfaYdUBMa8jtg2C3dPPPOKBVexqr03MzzfweXqmJSj27CwBLZ44uHwRTU3QbN+ISL+UEFvQRMyBy6pLZF1BsfkgevFK5hCbUEfMgmbteN/WFtHkAposYh2qiGnwMF+JaJFSSZ13P5hGrEIF0Qh6JjqRGGQMxAogIgi7OSlONxBY4eUSmWquq8tJLvHlYn+SwloDBH25PYqvM0tmFmdTrUqPMi9mq3pcgjl1WwWZV2D2sHE4ycpvdb4Dmb36j31dTs3yqu3NVOXAf0wMfndiSc7GX78FTUzZidB+fW+ltd5F9uvuXY3f+3vO0PGB8xh/tuPviXvvnPj76/G7MP5e/QHdTi2w8g/BFgAAAABJRU5ErkJggg==) no-repeat\"><\/em> <a href=\"http://www.pigcms.com/special/years4/\" target=\"_blank\" style=\"display:block;height:100%;width:100%;background:url(https://pigmcsdotcom.b0.upaiyun.com/statics/images/www/banner/actwindow.png) no-repeat\"><\/a><\/div><\/section>\n";
        $('body').append(actWindowStrVar)
		
		$(".flashBox>ul").prepend('<li class="banner-year4" style="background: url(https://pigmcsdotcom.b0.upaiyun.com/statics/images/www/banner/year4-1.png)"> <a href="http://www.pigcms.com/special/years4/" target="_blank"> <div class="warp pr"> <img src="https://pigmcsdotcom.b0.upaiyun.com/statics/images/www/banner/year4-2.png" class="pa"> </div> </a> </li>');

        $(".asideBanner").remove();

        var strVar = "";
        strVar += "<aside class=\"asideBanner\" id=\"asideBanner\"><div class=\"asideBannerIcon\"><\/div><section class=\"foorterBanner\"><div class=\"width1200\"><i><\/i> <input type=\"text\" name=\"phoneNum\" placeholder=\"留下联系方式 立即预约折扣 \"> <button><\/button> <a href=\"http://crm2.qq.com/page/portalpage/wpa.php?uin=800022936&aty=0&a=0&curl=&ty=1\" target=\"_blank\" class=\"a2\"><em><\/em>在线咨询<\/a> <a href=\"http://www.pigcms.com/special/years4/\" target=\"_blank\" class=\"a3\"><em><\/em>活动详情<\/a><\/div><\/section><\/aside>\n";

        $('body').append(strVar)
    };

    banner(".flashBox>ul >li", ".bannerSpot li", "5000", ".switchButton ", ".switchButton .prov", ".switchButton .next") //轮播图切换
    $('.downloadApp').on('click', ' div>i', function(event) { //点击app 出现列表
        $(this).parent().slideUp('300');
        $(this).parent().prev('').slideDown('300');
    });
    $('.header .nav li.last ol li dl dd span').click(function(event) { //点击app 出现二维码
        if ($(this).parents('.downloadApp ').hasClass('small')) {
            return
        }
        $(this).parents('dl').slideUp('300');
        $(this).parents().next('').slideDown('300');
    });
    $('.header .nav li.last ol li').hover(function() { //点击二维码关闭按钮
        $(this).find('.downloadApp').stop().fadeIn('300');
    }, function() {
        $(this).find('.downloadApp').fadeOut('300');
    });
    $('.bannerAside>i').click(function(event) {
        $(this).parent().fadeOut('500');
    });
    switching(".bannerTitle li", ".bannerArticle>li", "active"); //banner 右侧菜单
    switching(".productTitle ul li", ".articleTable>.article", "active"); //源码代理大切换
    switching(".productListCentent>li.systemList nav li", ".systemListCentent>li", "active"); //微信营销 功能体系
    switching(".productProfitTitle li", ".productProfitCentent>li", "active"); //微信营销 功能体系
    switching(".detailsTitle li", ".articleTable>.article", "active"); //详情页面头部页面
    // switching(".technical .navigation dd", ".technicalList >.section", "active"); //技术团队
    switchingProduct(".productCentent .productListTitle li", "active"); //微信营销大切换
    notice('.productTitle h3 p'); //滚动广告
    var width = $(window).width();
    $('.foorterBanner').css({ 'left': -width, 'width': width,'display':'block'});
    $('.asideBannerIcon').click(function(event) {
        $(this).animate({
            'left': '-100%'
        });

        $('.foorterBanner').animate({
            'left': '0',
            'width': width
        }, 300);
    });
    $('.foorterBanner div>i').click(function(event) {
        $('.foorterBanner').animate({
            'left': '-' + width
        });
        $('.asideBanner').css('width', '2%');
        $('.asideBannerIcon').animate({
            'left': '0'
        }, 300);
    });
    $(window).scroll(function() {
        if ($(window).scrollTop() > 200) {
            $(".backTop").fadeIn(0);
        } else {
            $(".backTop").fadeOut(500);
        }
    });
    $(".backTop").click(function() {
        $('body,html').animate({
                scrollTop: 0
            },
            500);
        return false;
    });
    $('.openLi').hover(function() {
        $(this).stop().animate({
            'width': '170px'
        });

    }, function() {
        $(this).stop().animate({
            'width': '69px'
        });
    });
    $('li.WeChat').hover(function() { //右侧展开微信
        $(this).find('div').stop().fadeToggle('300')
    });
    $('.development').click(function(event) {
        systole();
    });
    //systole();
    if ($('.environmentArticle').next().css('display') == 'block') {
        systole();
    }
    contact();
    jobTab();
    $('.indexAside dl').click(function(event) {
        var　 index = $(this).index();
        $('.articleTable .article').eq(index).show();
    });
    bannerDown(".environment>.environmentList") //单个切换效果
 /** 侧边栏删除修改**/
     $('.navigation i.close').click(function(event) {
        $('.navigation').hide('300');
        $('.navigationListClose').show('300');
    });
    $('.navigationListClose').click(function(event) {
        $('.navigation').show('300');
        $('.navigationListClose').hide('300');
    });
})

function bannerDown(a, b, c) {
    $.each($('.environment .environmentList'), function(i, item) {
        var nowDom = $(item);
        var a = $(item).find('ul li');
        var b = $(item).prev().find('.prev');
        var c = $(item).prev().find('.next');
        var len = a.length;
        if (len < 4) {
            $(item).prev().hide();
        }
        var num = len;
        var width = a.outerWidth(true);
        console.log(width);
        for (var i = 0; i < len; i++) {
            a.eq(i).css("left", width * i);
        }
        a.parent().css({
            "width": a.outerWidth(true) * len
        });
        $(b).click(function() {
            console.log(11)
            if (num >= len) {
                return
            } else {
                num++;
                for (var i = 0; i < len; i++) {
                    a.eq(i).stop().animate({
                        left: '+=' + width
                    });
                }
            }
            //table(num);
        });
        c.click(function() {
            console.log(num)
            if (num <= 3) {
                for (var i = 0; i < len; i++) {
                    a.eq(i).stop().animate({
                        left: width * i
                    });
                }
                num = len;
            } else {
                num--;
                for (var i = 0; i < len; i++) {
                    a.eq(i).stop().animate({
                        left: '-=' + width
                    });
                }
            }
            //table(num);
        });
    })

}

function jobTab() {
    var tabOgj = $(".jobs");
    tabOgj.each(function() {
        var that = $(this);
        var l = that.find(".job_list ul li");
        l.on("click", function() {
            //            console.log(411);
            var el = $(this);
            var thisIndex = l.index(el);
            el.addClass("on").siblings().removeClass("on");
            that.find(".job_cont .jobDetail").eq(thisIndex).fadeIn().siblings().hide()
        }).eq(0).trigger('click')
    })
}

function contact() {
    var conObj = $(".contactUs");
    var l = conObj.find(".hd li");
    l.click(function() {
        $(this).addClass("on").siblings().removeClass('on');
        if ($(this).attr('data') == 'bj') {
            $(".myAddress .bd .row").hide().eq(1).show();
            $(".contactUs .myMap").animate({
                "width": '0'
            }, 500, function() {
                $(".contactUs .myAddress").animate({
                    'left': "0",
                    'width': '100%'
                }, 500)
            })
        } else {
            $(".myAddress .bd .row").hide().eq(0).show();
            $(".contactUs .myAddress").css("width", 'auto');
            $(".contactUs .myAddress").animate({
                'left': "500px"
            }, 500, function() {
                $(".contactUs .myMap").animate({
                    "width": '460px'
                }, 500)
            })
        }
    }).eq(0).trigger('click')
}

function systole() {
    if (!$(".history").length) {
        return
    }
    var $warpEle = $(".history-date"),
        $targetA = $warpEle.find("h2 a,ul li dl dt a"),
        parentH, eleTop = [];
    parentH = $warpEle.parent().height();
    console.log(parentH);
    $warpEle.parent().css({
        "height": 59
    });
    setTimeout(function() {
        $warpEle.find("ul").children(":not('h2:first')").each(function(idx) {
            eleTop.push($(this).position().top);
            $(this).css({
                "margin-top": -eleTop[idx]
            }).children().hide()
        }).animate({
            "margin-top": 0
        }, 1600).children().fadeIn();
        $warpEle.parent().animate({
            "height": parentH
        }, 2600);
        $warpEle.find("ul").children(":not('h2:first')").addClass("bounceInDown").css({
            "-webkit-animation-duration": "2s",
            "-webkit-animation-delay": "0",
            "-webkit-animation-timing-function": "ease",
            "-webkit-animation-fill-mode": "both"
        }).end().children("h2").css({
            "position": "relative"
        })
    }, 600);
    $targetA.click(function() {
        $(this).parent().css({
            "position": "relative"
        });
        $(this).parent().siblings().slideToggle();
        $warpEle.parent().removeAttr("style");
        return false
    })
};

function banner(a, b, t, s, p, n) {
    var time = 0;
    var dd = $(a).length;
    var ht = "<li></li>";
    $(a).eq(0).show();
    for (var i = 0; i < dd - 1; i++) {
        ht += "<li></li>";
    }
    var i = 0;
    $(b).parent().html(ht);
    $(b).eq(0).addClass("active");

    function table() {
        $(a).eq(i).addClass("active").fadeIn(500).siblings().fadeOut(300).removeClass('active');
        $(b).eq(i).addClass("active").siblings('').removeClass('active');
    }
    $(a).parent().parent().hover(function() {
        $(s).show();
        clearInterval(time);
    }, function() {
        $(s).hide();
        dingshi();
    });

    function right() {
        if (i == dd - 1) {
            i = 0;
        } else {
            i++;
        }
    }

    function left() {
        if (i == 0) {
            i = dd - 1;
        } else {
            i--;
        }
    }

    function dingshi() {
        time = setInterval(function() {
            right();
            table();
        }, t);
    };
    $(b).click(function() {
        i = $(this).index();
        table();
    });
    $(b).eq(0).trigger("click");
    $(p).click(function() {
        left();
        table();
    });
    $(n).click(function() {
        right();
        table();
    });
}

function switching(a, b, c, d) { //切换
    function zhixing(index) {
        $(a).eq(index).addClass(c).siblings().removeClass(c);
        $(b).eq(index).addClass(d).show().siblings().hide().removeClass(d);
    }

    $(a).click(function() {
        var index = $(this).index();
        zhixing(index);
    });
};

function switchingProduct(a, c) { //切换
    $(a).hover(function() {
        var index = $(this).index();
        $(this).addClass(c).siblings().removeClass(c);
        $(this).parent().next().children('li').eq(index).show().siblings().hide();

    });
};

function notice(a) { //广告滚动
    var i = 1;
    var len = $(a).length;
    $(a).eq(0).show();
    setInterval(function() {
        $(a).eq(i).slideDown('200').siblings(a).hide();
        i++;
        if (i == len) {
            i = 0
        }
    }, 5000)
};

//判断当前时间是否在一个时间段内
var JudgeTime= function ()
{
    //将计划开始时间转成以秒为单位：
    var   planStartTime = "2017-6-5";
    var startTime = new Array();
    startTime = planStartTime.split('-');
    planStartTime = Date.UTC(parseInt(startTime[0]), parseInt(startTime[1]), parseInt(startTime[2]));
    //将计划结束时间转成以秒为单位：
    var planStopTime = "2017-6-11";
    var stopTime = new Array();
    stopTime = planStopTime .split('-');
    planStopTime = Date.UTC(parseInt(stopTime[0]), parseInt(stopTime[1]), parseInt(stopTime[2]));
    //将当前系统时间转化成以秒为单位：
    //获取当前时间
    var nowDate = new Date();
    //当前年
    var nowYear = nowDate.getFullYear();
    //当前月，记得要加1
    var nowMonth = (nowDate.getMonth() + 1);
    //当前日
    var nowDay = nowDate.getDate();
    var nowTime = Date.UTC(nowYear,nowMonth,nowDay);
    //判断：如果当前系统时间大于等于开始时间以及小于等于结束时间则登记成功
    if (nowTime >= planStartTime && nowTime <= planStopTime) {
        return true;
    } else {
        return false;
    }
};
try {
    if (window.console && window.console.log) {

        console.log("\n\n");
        console.log("这里有最炫酷的职位,最诱人的薪资，我在小猪，等你来！\n\n");
        console.log('如何让我遇见你，在你最美的时候\n加入小猪CMS，让我们从现在起起，和互联网大佬们，聊聊下一个风口在哪里！\n');
        console.log("请将简历发送至 %c hr@pigcms.cn（邮件标题请以姓吿-应聘XX职位-来自console命名）", "color:#0b8");
        console.log("职位介绍：http://www.pigcms.com/contact/job/\n\n");
        console.log('有梦想，才能改变世界！\n');
    }
} catch (e) {}
